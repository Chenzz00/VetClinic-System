AccountHistory - Admin
AppointmentWindow - Admin
AppointSched - Admin
changepass - Pet Owner
DiagnosisForm - Pet Owner (pop-up)
forgotPass - Pet Owner
homepage - Pet Owner 
login - All
mail - Pet Owner
PetOwnerHistory - ()
profile - Pet Owner
reg - Pet Owner
transaction - ()
transaction_history - All
VetWindow - Vet
